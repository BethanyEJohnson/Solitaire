package application;

import java.util.LinkedList;

public interface Iterator {
	public boolean hasNext();
	public Object next();
}

interface Container {
	public Iterator getIterator();
	
}

class CardStack implements Container {
	public LinkedList<Card> cards;
	
	@Override
	public Iterator getIterator() {
		return new CardIterator();
	}
	
	private class CardIterator implements Iterator {

		int idx;
		
		public boolean hasNext() {
			if(idx < cards.size())
				return true;
			return false;
		}

		public Object next() {
			if(this.hasNext())
				return cards.get(idx++);
			return null;
		}
		
	}
	
}